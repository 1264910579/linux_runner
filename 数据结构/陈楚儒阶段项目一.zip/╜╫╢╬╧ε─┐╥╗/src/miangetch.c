#include <termio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define PRI_STYLE(type,str) printf("\e[%dm%s\e[m",(type),(str))
#define PRI_STYLES(type,str) printf("\e[%dm %c \e[4m",(type),(str))
#define Back_COLOR 41+rand()%7
#define FRONT_COLOR 31+rand()%7
int main(int argc, char const *argv[])
{
while (1)
{
        printf("\e[0;0H");
        for(int i= 1 ;i<=10;i++)
            PRI_STYLE(FRONT_COLOR,"*");
        
        PRI_STYLE(FRONT_COLOR,"烦烦烦烦烦烦烦烦烦方法");
        
        for(int i= 1 ;i<=10;i++)
            PRI_STYLE(FRONT_COLOR,"*");
        
        PRI_STYLE(FRONT_COLOR,"\n\n         欢迎使用          \n");
        PRI_STYLE(FRONT_COLOR,"      输入任意键开始   \n\n");

        for(int i= 1 ;i<=26;i++)
            PRI_STYLE(FRONT_COLOR,"*");
        printf("\n");
            PRI_STYLE(FRONT_COLOR,"（你打字快吗？）\n");
        
         usleep(500*1000);
}
    return 0;
}

